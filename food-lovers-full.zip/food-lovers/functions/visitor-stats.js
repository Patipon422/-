import {createHash} from 'node:crypto';
import {FieldValue, Timestamp} from 'firebase-admin/firestore';
import {HttpsError} from 'firebase-functions/v2/https';

export const VISIT_WINDOW_MS = 30 * 60 * 1000;
export const bangkokDay = now => new Date(now + 7 * 60 * 60 * 1000).toISOString().slice(0, 10);

// Only a random browser ID is accepted. Never accept counters or time from clients.
export function visitorHash(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data) ||
      Object.keys(data).length !== 1 ||
      typeof data.visitorId !== 'string' ||
      !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(data.visitorId)) {
    throw new HttpsError('invalid-argument', 'รหัสผู้เข้าชมไม่ถูกต้อง');
  }
  return createHash('sha256').update(data.visitorId.toLowerCase()).digest('hex');
}

// Inject the clock only from server/test code, never from the callable request.
export async function recordVisitor(db, data, now = Date.now()) {
  const hash = visitorHash(data);
  const visitorRef = db.doc(`visitorStats/${hash}`);
  const day = bangkokDay(now);
  return db.runTransaction(async tx => {
    const visitor = await tx.get(visitorRef);
    const lastCountedAt = visitor.data()?.lastCountedAt?.toMillis();
    if (Number.isFinite(lastCountedAt) && now - lastCountedAt < VISIT_WINDOW_MS) {
      return {counted: false, day};
    }
    // The visitor read serializes simultaneous requests for the same browser.
    // Atomic increments prevent different browsers from overwriting one another.
    const at = Timestamp.fromMillis(now);
    tx.set(visitorRef, {lastCountedAt: at});
    tx.set(db.doc('publicStats/total'), {
      visits: FieldValue.increment(1),
      uniqueBrowsers: FieldValue.increment(visitor.exists ? 0 : 1),
      updatedAt: at,
    }, {merge: true});
    tx.set(db.doc(`dailyStats/${day}`), {
      visits: FieldValue.increment(1), updatedAt: at,
    }, {merge: true});
    return {counted: true, day};
  });
}
