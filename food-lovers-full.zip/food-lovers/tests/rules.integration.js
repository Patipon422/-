import {test,before,after} from 'node:test';
import {readFileSync} from 'node:fs';
import {initializeTestEnvironment,assertFails,assertSucceeds} from '@firebase/rules-unit-testing';
import {doc,getDoc,setDoc,collection,getDocs,query,where,serverTimestamp} from 'firebase/firestore';
import {ref,uploadBytes,getBytes} from 'firebase/storage';
let env;
before(async()=>{env=await initializeTestEnvironment({projectId:'demo-kin-dee',firestore:{rules:readFileSync('firestore.rules','utf8')},storage:{rules:readFileSync('storage.rules','utf8')}});await env.withSecurityRulesDisabled(async c=>{await setDoc(doc(c.firestore(),'shops/public'),{status:'approved',submittedBy:'alice'});await setDoc(doc(c.firestore(),'shops/private'),{status:'pending',submittedBy:'alice'});await setDoc(doc(c.firestore(),'users/alice'),{email:'private@example.test',role:'student'});});});
after(async()=>env?.cleanup());
test('guests can read aggregate statistics but cannot list or change counters',async()=>{
 const db=env.unauthenticatedContext().firestore();
 await assertSucceeds(getDoc(doc(db,'publicStats/total')));
 await assertSucceeds(getDoc(doc(db,'dailyStats/2026-11-07')));
 await assertFails(getDocs(collection(db,'publicStats')));
 await assertFails(getDocs(collection(db,'dailyStats')));
 await assertFails(setDoc(doc(db,'publicStats/total'),{visits:9999}));
 await assertFails(setDoc(doc(env.authenticatedContext('admin',{admin:true}).firestore(),'dailyStats/2026-11-07'),{visits:9999}));
});
test('visitor records remain private even to logged-in clients',async()=>{
 await env.withSecurityRulesDisabled(async c=>setDoc(doc(c.firestore(),'visitorStats/private-hash'),{lastCountedAt:serverTimestamp()}));
 for(const db of [env.unauthenticatedContext().firestore(),env.authenticatedContext('alice').firestore()]){
  await assertFails(getDoc(doc(db,'visitorStats/private-hash')));
  await assertFails(getDocs(collection(db,'visitorStats')));
  await assertFails(setDoc(doc(db,'visitorStats/private-hash'),{lastCountedAt:serverTimestamp()}));
 }
});
test('guest reads approved but not pending',async()=>{const db=env.unauthenticatedContext().firestore();await assertSucceeds(getDoc(doc(db,'shops/public')));await assertFails(getDoc(doc(db,'shops/private')));await assertSucceeds(getDocs(query(collection(db,'shops'),where('status','==','approved'))));await assertFails(getDocs(collection(db,'shops')));});
test('owner can read own pending; other user cannot',async()=>{await assertSucceeds(getDoc(doc(env.authenticatedContext('alice').firestore(),'shops/private')));await assertFails(getDoc(doc(env.authenticatedContext('bob').firestore(),'shops/private')));});
test('client cannot approve shop or elevate role',async()=>{const db=env.authenticatedContext('alice').firestore();await assertFails(setDoc(doc(db,'shops/private'),{status:'approved'}));await assertFails(setDoc(doc(db,'users/alice'),{role:'admin'}));});
test('private email is not public',async()=>{await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(),'users/alice')));});
test('bookmarks belong to owner and approved shops only',async()=>{const db=env.authenticatedContext('alice').firestore();await assertSucceeds(setDoc(doc(db,'users/alice/bookmarks/public'),{shopId:'public',createdAt:serverTimestamp()}));await assertFails(setDoc(doc(db,'users/bob/bookmarks/public'),{shopId:'public',createdAt:serverTimestamp()}));await assertFails(setDoc(doc(db,'users/alice/bookmarks/private'),{shopId:'private',createdAt:serverTimestamp()}));});
test('storage rejects wrong owner MIME and oversized files',async()=>{const s=env.authenticatedContext('alice').storage();await assertFails(uploadBytes(ref(s,'pending/bob/test'),new Uint8Array([1]),{contentType:'image/jpeg'}));await assertFails(uploadBytes(ref(s,'pending/alice/test'),new Uint8Array([1]),{contentType:'text/plain'}));await assertFails(uploadBytes(ref(s,'pending/alice/large'),new Uint8Array(5*1024*1024+1),{contentType:'image/jpeg'}));await assertSucceeds(uploadBytes(ref(s,'pending/alice/photo'),new Uint8Array([1]),{contentType:'image/jpeg'}));await assertFails(getBytes(ref(env.unauthenticatedContext().storage(),'pending/alice/photo')));});
