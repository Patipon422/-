import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {getVisitorId, VISITOR_KEY, bangkokDay, displayCount} from '../src/utils/visitors.js';

test('visitor identity survives reload and an invalid saved value is repaired', () => {
  const values = new Map();
  const storage = {getItem:key=>values.get(key), setItem:(key,value)=>values.set(key,value)};
  const first = getVisitorId(storage, randomUUID);
  assert.ok(first);
  assert.equal(getVisitorId(storage, randomUUID), first);
  values.set(VISITOR_KEY, '<script>invalid</script>');
  assert.notEqual(getVisitorId(storage, randomUUID), first);
});

test('blocked storage skips counting instead of inventing new visitors', () => {
  assert.equal(getVisitorId({getItem(){throw Error('blocked');}}, randomUUID), null);
  assert.equal(getVisitorId({getItem(){},setItem(){throw Error('quota');}}, randomUUID), null);
});

test('today rolls over at midnight in Thailand, independent of host timezone', () => {
  assert.equal(bangkokDay(Date.parse('2026-11-07T16:59:59Z')), '2026-11-07');
  assert.equal(bangkokDay(Date.parse('2026-11-07T17:00:00Z')), '2026-11-08');
});

test('unknown statistics never render as fabricated zeroes or unsafe text', () => {
  for (const input of [null, undefined, NaN, -2, '<img>', Infinity]) assert.equal(displayCount(input), '—');
  assert.equal(displayCount(0), '0');
  assert.equal(displayCount(1234), '1,234');
});
