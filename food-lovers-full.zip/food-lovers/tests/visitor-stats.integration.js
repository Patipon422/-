import {test, after, beforeEach} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
process.env.GCLOUD_PROJECT='demo-kin-dee';
process.env.FIREBASE_CONFIG=JSON.stringify({projectId:'demo-kin-dee',storageBucket:'demo-kin-dee.appspot.com'});
const {recordVisit}=await import('../functions/index.js');
const {recordVisitor, visitorHash, VISIT_WINDOW_MS}=await import('../functions/visitor-stats.js');
const {getFirestore}=await import('../functions/node_modules/firebase-admin/lib/firestore/index.js');
const {getApps,deleteApp}=await import('../functions/node_modules/firebase-admin/lib/app/index.js');
const db=getFirestore();
const now=Date.parse('2026-11-07T10:00:00Z');
const total=async()=>(await db.doc('publicStats/total').get()).data();
beforeEach(async()=>{for(const name of ['publicStats','dailyStats','visitorStats'])await db.recursiveDelete(db.collection(name));});
after(async()=>{await Promise.all(getApps().map(deleteApp));});

test('anonymous first visit counts; reloads and simultaneous tabs count only once',async()=>{
  const data={visitorId:randomUUID()};
  const results=await Promise.all(Array.from({length:6},()=>recordVisit.run({data})));
  assert.equal(results.filter(r=>r.counted).length,1);
  const stats=await total();assert.equal(stats.visits,1);assert.equal(stats.uniqueBrowsers,1);
  assert.equal((await db.collection('visitorStats').get()).size,1);
  assert.equal(Object.keys((await db.doc(`visitorStats/${visitorHash(data)}`).get()).data()).join(','),'lastCountedAt');
});

test('a later visit adds a visit but not a new browser; independent browsers aggregate',async()=>{
  const a={visitorId:randomUUID()}, b={visitorId:randomUUID()};
  await Promise.all([recordVisitor(db,a,now),recordVisitor(db,b,now)]);
  assert.equal((await recordVisitor(db,a,now+VISIT_WINDOW_MS-1)).counted,false);
  assert.equal((await recordVisitor(db,a,now+VISIT_WINDOW_MS)).counted,true);
  const stats=await total();assert.equal(stats.visits,3);assert.equal(stats.uniqueBrowsers,2);
  assert.equal((await db.doc('dailyStats/2026-11-07').get()).data().visits,3);
});

test('Bangkok daily totals separate days without resetting all-time totals',async()=>{
  const data={visitorId:randomUUID()};
  await recordVisitor(db,data,Date.parse('2026-11-07T16:45:00Z'));
  assert.equal((await recordVisitor(db,data,Date.parse('2026-11-07T17:00:00Z'))).counted,false);
  assert.equal((await db.doc('dailyStats/2026-11-08').get()).exists,false);
  await recordVisitor(db,data,Date.parse('2026-11-07T17:15:00Z'));
  assert.equal((await db.doc('dailyStats/2026-11-07').get()).data().visits,1);
  assert.equal((await db.doc('dailyStats/2026-11-08').get()).data().visits,1);
  assert.equal((await total()).visits,2);assert.equal((await total()).uniqueBrowsers,1);
});

test('clients cannot inject counts, server time or arbitrary visitor paths',async()=>{
  for(const data of [null,{},[],{visitorId:'../../users/admin'},{visitorId:randomUUID(),visits:9999},{visitorId:randomUUID(),now:0}]){
    await assert.rejects(recordVisit.run({data}),err=>err.code==='invalid-argument');
  }
  assert.equal((await db.doc('publicStats/total').get()).exists,false);
});
