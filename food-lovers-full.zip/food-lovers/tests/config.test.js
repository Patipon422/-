import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFirebaseConfig} from '../src/utils/firebase-config.js';
const config = {apiKey:'public-key',authDomain:'project.firebaseapp.com',projectId:'project',storageBucket:'project.firebasestorage.app',appId:'web:app',appCheckSiteKey:'site-key'};
test('missing real configuration stops startup without a local-data fallback', () => {
  assert.throws(() => readFirebaseConfig(), {code:'app/config-missing'});
  assert.throws(() => readFirebaseConfig({...config,apiKey:'YOUR_API_KEY'}), {code:'app/config-missing'});
});
test('public runtime configuration and existing environment configuration both work', () => {
  assert.equal(readFirebaseConfig(config).appCheckProvider, 'enterprise');
  assert.equal(readFirebaseConfig({...config,appCheckProvider:'v3'}).appCheckProvider, 'v3');
  assert.equal(readFirebaseConfig({...config,apiKey:''},{VITE_FIREBASE_API_KEY:'env-key'}).apiKey,'env-key');
});
