import {test} from 'node:test';
import assert from 'node:assert/strict';
import {draftKey,saveDraft,readDraft,clearDraft} from '../src/utils/drafts.js';
const storage=()=>{const values=new Map();return {getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};};
test('draft survives reload with repeated tags, empty fields and Thai text',()=>{
 const db=storage(),key=draftKey('demo','student'),fields=[['name','ครัวหลังมอ'],['tags','Wi-Fi'],['tags','ปลั๊กไฟ'],['phone','']];
 saveDraft(db,key,fields);assert.deepEqual(readDraft(db,key),fields);
 clearDraft(db,key);assert.equal(readDraft(db,key),null);
});
test('drafts are isolated by account, data mode and edit target',()=>{
 const db=storage();saveDraft(db,draftKey('demo','student'),[['name','ร้านแรก']]);
 for(const key of [draftKey('demo','admin'),draftKey('firebase','student'),draftKey('demo','student','demo-1')])assert.equal(readDraft(db,key),null);
});
test('corrupt draft reports an error without deleting stored data',()=>{
 const db=storage(),key=draftKey('demo','student');db.setItem(key,'broken');
 assert.throws(()=>readDraft(db,key));assert.equal(db.getItem(key),'broken');
});
