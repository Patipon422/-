# สถิติผู้เข้าชม

อ่านขั้นตอนเชื่อมระบบครบที่ README.md ก่อน ระบบนี้ใช้ Firebase project เดียวกับร้าน สมาชิก และรีวิว

1. ตั้งค่า Firebase และ App Check ใน public/firebase-config.js
2. Deploy Cloud Functions, Firestore rules และ Hosting ตาม README
3. เปิดเว็บจริงโดยไม่ต้องเข้าสู่ระบบ สถิติจะถูกสร้างเมื่อ recordVisit สำเร็จครั้งแรก
4. บนหน้าสถิติจะแสดงยอดรวม วันนี้ (Asia/Bangkok) และเบราว์เซอร์สะสม จาก Firestore แบบเรียลไทม์

เซิร์ฟเวอร์ใช้ transaction และเวลาเซิร์ฟเวอร์ นับใหม่ได้ทุก 30 นาทีต่อ browser ID ห้ามเปิดสิทธิ์เขียน publicStats/dailyStats ให้ client ถ้าเชื่อมต่อไม่ได้จะแสดง — หรือสถานะผิดพลาด ไม่ใช้ตัวเลขสุ่มหรือยอด localStorage แทน

ทดสอบด้วย npm run test:integration ครอบคลุม concurrent visits, ไม่ซ้ำภายใน 30 นาที, ยอดรายวันข้ามเที่ยงคืนไทย และการปฏิเสธการแก้ยอดจาก client

ดู logs ของ recordVisit เมื่อไม่มีการนับ ตรวจ App Check, region asia-southeast1 และ projectId ให้ตรงกัน ถ้าแสดงยอดได้แต่ไม่นับ อาจเป็นเพราะ App Check ไม่ผ่านหรือ browser ไม่อนุญาต localStorage
