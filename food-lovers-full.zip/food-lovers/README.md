# ลัทธิคนรักอาหาร • มธ.ลำปาง

ฉบับเต็ม 2.0.0 — วันที่ 8 พฤศจิกายน 2569

เว็บไซต์รวมร้านอาหาร คาเฟ่ และบริการรอบมหาวิทยาลัยธรรมศาสตร์ ศูนย์ลำปาง
เก็บข้อมูลร่วมกันผ่าน Firebase เท่านั้น ไม่มีบัญชีสำเร็จรูป ไม่มีข้อมูลร้านสมมติ และไม่มีระบบจำลองข้อมูลในเบราว์เซอร์

**เริ่มอ่านที่ `START-HERE.html`** โดยดับเบิลคลิกเปิดในเบราว์เซอร์

## สถานะของไฟล์ชุดนี้

- มีซอร์สโค้ดหน้าเว็บ ระบบหลังบ้าน กฎสิทธิ์ ไฟล์เว็บที่ build แล้ว และคู่มือ
- ยังไม่มีค่า Firebase ของเจ้าของเว็บไซต์ และยังไม่ได้เผยแพร่ไปยังโดเมนจริง
- เมื่อยังไม่ตั้งค่า เว็บไซต์จะแสดงหน้ารอเปิดบริการ ไม่แสดงร้านหรือสถิติที่สร้างขึ้นเอง
- ระบบสมาชิก อัปโหลดรูป บันทึกร้าน รีวิว อนุมัติร้าน และสถิติ จะใช้งานร่วมกันได้หลังตั้งค่าและ deploy Firebase ครบ
- การเปิด `dist/index.html` ด้วย file:// ไม่ใช่วิธีรันเว็บ ต้องใช้ HTTP server หรือ Hosting

## ความสามารถ

1. ค้นหาร้านตามชื่อ เมนู หมวดหมู่ ราคา สิ่งอำนวยความสะดวก เวลาเปิด และคะแนน
2. แผนที่ OpenStreetMap พร้อมหมุดร้าน จัดกลุ่มหมุด และลิงก์นำทาง Google Maps
3. เข้าสู่ระบบด้วย Google และบันทึกร้านโปรดข้ามอุปกรณ์
4. เสนอร้านและแก้ไขข้อเสนอที่ยังไม่อนุมัติ พร้อมเลือกรูปสูงสุด 5 รูป รูปละไม่เกิน 5 MB
5. เก็บร่างข้อความฟอร์มไว้ในอุปกรณ์ แยกตามบัญชี ไม่รวมไฟล์รูป
6. รีวิว 1–5 ดาว แก้ไขและลบรีวิวตนเอง คะแนนรวมคำนวณในธุรกรรมฝั่งเซิร์ฟเวอร์
7. ผู้ดูแลอนุมัติ ปฏิเสธพร้อมเหตุผล เก็บร้านเข้าคลัง ซ่อนรีวิว จัดการรายงาน และดูประวัติ
8. แจ้งผลตรวจร้านในหน้าบัญชีแบบเรียลไทม์
9. สถิติสาธารณะ: เข้าชมทั้งหมด วันนี้ และจำนวนเบราว์เซอร์สะสม
10. หน้าจอรองรับมือถือ มีเมนูล่าง และโลโก้โดมแบบเรขาคณิต

## สิ่งที่ต้องเตรียม

- Node.js 22 LTS และ npm
- Firebase project ของคุณ พร้อมเปิด Authentication (Google), Firestore แบบ Native/default database และ Storage
- Cloud Functions และ Storage ต้องใช้แผน Blaze ที่เชื่อม Cloud Billing ค่าใช้จ่ายขึ้นกับการใช้งาน ตั้ง Budget alert ก่อนเปิดสาธารณะ
- Firebase Web App config จาก Project settings > General > Your apps
- App Check สำหรับเว็บ: ใช้ reCAPTCHA Enterprise เป็นค่าเริ่มต้น หรือเลือก `v3` สำหรับโครงการเดิม
- บัญชี Google สำหรับผู้ดูแล และสิทธิ์ deploy ใน Firebase project

## 1. เชื่อม Firebase

แก้ไฟล์ `public/firebase-config.js` ให้ตรงกับโครงการของคุณ:

```js
window.FOOD_LOVERS_FIREBASE = {
  apiKey: 'ค่าจาก Firebase',
  authDomain: 'ค่าจาก Firebase',
  projectId: 'ค่าจาก Firebase',
  storageBucket: 'ค่าจาก Firebase — คัดลอกตรง ๆ ไม่เดาชื่อ bucket',
  appId: 'ค่าจาก Firebase',
  appCheckSiteKey: 'public site key ของ reCAPTCHA',
  appCheckProvider: 'enterprise',
};
```

ไฟล์นี้เป็นค่า public ของเว็บ **ห้ามใส่ service-account JSON, private key หรือ reCAPTCHA secret key**

ใช้ `.env.local` ตาม `.env.example` ได้เช่นกัน ค่าที่ไม่ว่างใน `public/firebase-config.js` มีลำดับเหนือ environment
ไม่มีตัวเลือกสลับระบบข้อมูลอีกแล้ว

## 2. ตั้งค่าบน Console

1. เปิด Google ใน Authentication > Sign-in method และกำหนด support email
2. เพิ่มโดเมนจริงใน Authentication > Settings > Authorized domains หากทดสอบ localhost ให้เพิ่ม localhost ด้วย
3. สร้าง Firestore default database และ Storage bucket ในโครงการเดียวกัน
4. ลงทะเบียนเว็บใน App Check ด้วย provider ให้ตรงกับ `appCheckProvider`; เพิ่มโดเมนจริงใน reCAPTCHA และนำ public site key มาใส่ไฟล์
5. Callable Functions ทุกตัวบังคับ App Check อยู่แล้ว ห้ามปิดการตรวจเพื่อแก้ปัญหาการเชื่อมต่อ
6. หลังตรวจว่าเว็บส่ง token สำเร็จ ให้เปิด enforcement สำหรับ Firestore และ Storage ใน Console
7. สำหรับการพัฒนา localhost ใช้ App Check debug provider ตามเอกสาร Firebase เฉพาะเครื่องพัฒนา ห้ามนำ debug token ขึ้นเว็บจริง

## 3. ติดตั้งและเผยแพร่

เปิด Terminal/PowerShell ในโฟลเดอร์ที่มี package.json:

```sh
npm ci
npm ci --prefix functions
npx firebase login
npx firebase use --add
npm run check:config
npm test
npm run deploy
```

ตอน `firebase use --add` เลือกโครงการเดียวกับ `projectId` ในไฟล์ตั้งค่า คำสั่ง deploy จะตรวจว่ากรอกค่าครบ สร้างไฟล์เว็บ และอัปโหลด Hosting, Functions, Firestore rules/indexes และ Storage rules

`check:config` ตรวจความครบถ้วนของช่องเท่านั้น ไม่ยืนยันว่า credentials, App Check หรือบริการบน Console ใช้งานได้

หลัง deploy จะได้ URL จาก Firebase CLI ฟังก์ชันใช้ภูมิภาค `asia-southeast1` อย่าเปลี่ยนเฉพาะฝั่งใดฝั่งหนึ่ง

### ใช้ไฟล์ที่ build ไว้ใน dist

แก้ `dist/firebase-config.js` แล้วอัปโหลดไฟล์ภายใน dist ไปยังโฮสต์ที่รองรับ SPA rewrite ทุกเส้นทางไป `index.html` ได้โดยไม่ต้อง build หน้าเว็บใหม่ แต่ยังต้อง deploy Functions และ rules ไปยัง Firebase project และตั้งโดเมน Auth/App Check/CORS ให้ครบ

ถ้ากลับไปสั่ง build ใหม่ จะคัดลอกไฟล์จาก `public/firebase-config.js` มาทับ dist ให้แก้ทั้งสองตำแหน่งให้ตรงกัน

## 4. ตั้งค่า CORS สำหรับภาพที่รออนุมัติ

ระบบอ่านภาพรอตรวจด้วย Firebase Storage SDK เพื่อรักษาสิทธิ์เจ้าของรูปและผู้ดูแล จึงต้องตั้ง CORS ของ bucket ให้รับ origin ของเว็บจริง

แก้ `storage.cors.json` แทน `https://YOUR_PROJECT_ID.web.app` ด้วย origin ที่ใช้งานจริง เพิ่มโดเมนกำหนดเองถ้ามี จากนั้นใช้ Google Cloud CLI ที่ลงชื่อเข้าใช้โครงการนี้แล้ว:

```sh
gcloud storage buckets update gs://YOUR_ACTUAL_STORAGE_BUCKET --cors-file=storage.cors.json
```

แทน bucket ด้วยค่าจาก Firebase Console ไม่รวม `gs://` ซ้ำ คำสั่งนี้ต้องทำแยกจาก `firebase deploy`

## 5. สร้างผู้ดูแลคนแรก

1. เปิดเว็บจริงและเข้าสู่ระบบด้วย Google หนึ่งครั้ง
2. คัดลอก UID บัญชีจาก Firebase Console > Authentication > Users
3. รันสคริปต์ด้วย Admin SDK credentials บนเครื่องที่เชื่อถือได้ ตัวอย่าง PowerShell:

```powershell
$env:GOOGLE_APPLICATION_CREDENTIALS="C:\secure\service-account.json"
$env:GOOGLE_CLOUD_PROJECT="YOUR_PROJECT_ID"
node scripts/set-admin.mjs YOUR_USER_UID
```

ใช้ credentials ของโครงการเดียวกัน เก็บ service-account file นอกโฟลเดอร์เว็บ ไม่แนบใน ZIP และไม่อัปโหลดไป Hosting

4. ออกจากระบบและเข้าสู่ระบบใหม่ แล้วเปิด `/admin`
5. เสนอร้านจริงผ่าน `/submit` และอนุมัติผ่าน `/admin` ร้านจึงปรากฏต่อสาธารณะ ไม่มีการเติมร้านตัวอย่างอัตโนมัติ

## ตรวจงานหลังเปิดใช้งาน

- Google sign-in ทำงานบนโดเมนจริง; บัญชีทั่วไปเปิดผู้ดูแลไม่ได้
- ผู้ใช้เสนอร้านพร้อมรูปได้ และคนอื่นยังอ่านร้านที่รอตรวจไม่ได้
- ผู้ดูแลเห็นรูปและอนุมัติร้านได้ ผู้เสนอได้รับแจ้งผล
- เปิดเว็บอีกอุปกรณ์เห็นร้านที่อนุมัติและรีวิวเดียวกัน
- บันทึกร้าน/แก้ไขรีวิว/ซ่อนรีวิวแล้วคะแนนถูกต้อง
- สถิติเพิ่มจากเบราว์เซอร์ใหม่ รีเฟรชภายใน 30 นาทีไม่นับซ้ำ
- ทดสอบทุก flow บนมือถือและเดสก์ท็อปก่อนประกาศเปิดสาธารณะ

## คำสั่งพัฒนาและทดสอบ

```sh
npm run dev
npm run build
npm run preview
npm test
npm run test:integration
```

Integration tests ใช้ Firebase Emulator แยกจากข้อมูลจริง ต้องมี Java และดาวน์โหลด emulator ได้ ชื่อ project ที่ขึ้นต้น `demo-` ใน tests เป็นชื่อ sandbox ตาม convention ของ Firebase เท่านั้น ไม่มีผลกับเว็บที่เผยแพร่

ผลตรวจในชุดส่งมอบ: unit tests 19/19 และ integration tests 13/13 ผ่าน, production build ผ่าน ตรวจหน้าแจ้งสถานะเมื่อยังไม่ตั้งค่าในเบราว์เซอร์แล้ว แต่ยังไม่ได้ทดสอบ Google login/App Check/การอัปโหลดจริงบน Firebase ของเจ้าของ เพราะยังไม่มีการตั้งค่าโครงการ

## โครงสร้าง

- `src/` — หน้าจอ แผนที่ Firebase repository และสถิติ
- `public/` — โลโก้ ภาพสำรอง และ config สำหรับ build
- `dist/` — เว็บที่ build แล้วพร้อมกรอก config
- `functions/` — ตรวจข้อมูล อนุมัติร้าน ประมวลผลภาพ คำนวณคะแนน และนับผู้เข้าชม
- `firestore.rules`, `storage.rules` — กฎการอ่านเขียน
- `scripts/` — ตรวจ config และแต่งตั้ง admin
- `tests/` — unit/integration tests ไม่เชื่อมฐานข้อมูลจริง

## ข้อควรทราบ

สถิตินับเบราว์เซอร์จาก UUID ไม่ใช่บุคคลจริง ผู้ใช้ที่ล้างข้อมูลอาจถูกนับใหม่ App Check ช่วยลด abuse แต่ไม่รับประกันการป้องกันบอตทั้งหมด ระบบสถิติไม่เก็บชื่อ อีเมล หรือ IP ในเอกสารสถิติ; ผู้ให้บริการโครงสร้างพื้นฐานอาจมี access logs ตามนโยบายของผู้ให้บริการ

แผนที่และภาพปกหน้าแรกใช้บริการภายนอก ภาพปก Unsplash เป็นภาพตกแต่ง ไม่ผูกเป็นภาพร้านจริง รูปจริงในร้านมาจากผู้ใช้และต้องผ่านการตรวจสอบก่อนเผยแพร่

Repository อ่านรายการเป็นชุดละ 200 จนครบ ป้องกันข้อมูลหายเมื่อมีมากกว่า 200 รายการ แต่เมื่อชุมชนโตมากควรเพิ่ม server-side pagination/search เพื่อลดค่าอ่าน Firestore และเวลาโหลด

## เอกสารทางการ

- Firebase Web setup: https://firebase.google.com/docs/web/setup
- Google login: https://firebase.google.com/docs/auth/web/google-signin
- App Check Enterprise: https://firebase.google.com/docs/app-check/web/recaptcha-enterprise-provider
- Cloud Functions: https://firebase.google.com/docs/functions/get-started
- Cloud Storage และข้อกำหนด Blaze: https://firebase.google.com/docs/storage/web/start
- Storage download และ CORS: https://firebase.google.com/docs/storage/web/download-files
