import {getVisitorId, displayCount} from './utils/visitors.js';

export function createVisitorStatistics({onChange}) {
  let data = null, status = 'loading', trackFailed = false;
  let repository, unsubscribe, deadline, pending = false, lastAttempt = 0;
  let visitorId = null, disposed = false;

  function markup() {
    const labels = {loading:'กำลังโหลดสถิติ', live:'อัปเดตจากผู้เข้าชมจริง', cached:'ข้อมูลล่าสุดที่บันทึกไว้', error:'เชื่อมต่อสถิติไม่ได้'};
    const available = data && status !== 'error';
    return `<div class="visitor-heading"><div><p class="section-overline">ทุกการแวะมา เป็นส่วนหนึ่งของเรา</p><h2 id="visitor-heading">ชุมชนคนรักอาหาร</h2></div><span class="visitor-status ${status}" role="status"><span class="dot"></span>${labels[status]}</span></div>
      <dl class="visitor-metrics"><div><dt>เข้าชมทั้งหมด</dt><dd>${displayCount(available ? data.totalVisits : null)}<span>ครั้ง</span></dd></div><div><dt>เข้าชมวันนี้</dt><dd>${displayCount(available ? data.todayVisits : null)}<span>ครั้ง</span></dd></div><div><dt>ผู้เข้าชมสะสม</dt><dd>${displayCount(available ? data.totalBrowsers : null)}<span>เบราว์เซอร์</span></dd></div></dl>
      <p class="visitor-note">นับการเข้าชมใหม่ได้ทุก 30 นาทีต่อเบราว์เซอร์ · วันนี้อิงเวลาไทย</p>
      ${(!visitorId || trackFailed) ? `<p class="visitor-note">${!visitorId ? 'เบราว์เซอร์นี้ไม่อนุญาตให้บันทึกรหัสผู้เข้าชม จึงอ่านสถิติได้แต่ไม่นับการเข้าชมนี้' : 'ยังบันทึกการเข้าชมครั้งนี้ไม่ได้'}</p>` : ''}
      ${(status === 'error' || trackFailed) ? '<button class="visitor-retry" data-action="retry-stats">ลองเชื่อมต่ออีกครั้ง</button>' : ''}
      <details class="visitor-details"><summary>นับสถิติอย่างไร</summary><p>นับการเปิดเว็บไซต์หรือกลับมาที่แท็บหลังครบ 30 นาทีจากครั้งที่นับล่าสุด การรีเฟรชและเปลี่ยนหน้าภายในช่วงนี้ไม่เพิ่มยอด “ผู้เข้าชมสะสม” นับจากรหัสสุ่มของแต่ละเบราว์เซอร์ ไม่ใช่จำนวนบุคคลจริง การล้างข้อมูลหรือเปลี่ยนอุปกรณ์อาจนับเป็นเบราว์เซอร์ใหม่ ระบบสถิติไม่บันทึกชื่อ อีเมล หรือ IP ลงฐานข้อมูลสถิติ</p></details>`;
  }

  function publish() { if (!disposed) onChange(); }
  function watch() {
    unsubscribe?.(); clearTimeout(deadline);
    status = 'loading'; publish();
    deadline = setTimeout(() => {status = 'error'; publish();}, 15000);
    unsubscribe = repository.watchVisitorStats(next => {
      clearTimeout(deadline); data = next;
      status = next.fromCache ? 'cached' : 'live'; publish();
    }, () => {clearTimeout(deadline); status = 'error'; publish();});
  }

  async function track(force = false) {
    if (!visitorId || pending || (!force && Date.now() - lastAttempt < 60000)) return;
    pending = true; lastAttempt = Date.now();
    try {
      await repository.call('recordVisit', {visitorId});
      trackFailed = false;
    } catch {trackFailed = true;}
    finally {pending = false; publish();}
  }
  const resume = () => {if (document.visibilityState === 'visible') void track();};
  const online = () => {watch(); void track(true);};

  return {
    markup,
    section: () => `<section class="visitor-section" aria-labelledby="visitor-heading" data-visitor-stats>${markup()}</section>`,
    start(repo) {
      repository = repo;
      try {visitorId = getVisitorId(window.localStorage, () => crypto.randomUUID());} catch {visitorId = null;}
      watch();
      if (document.visibilityState === 'visible') void track();
      document.addEventListener('visibilitychange', resume);
      window.addEventListener('online', online);
    },
    retry() {if (repository) {watch(); void track(true);}},
    dispose() {disposed = true; unsubscribe?.(); clearTimeout(deadline); document.removeEventListener('visibilitychange', resume); window.removeEventListener('online', online);},
  };
}
