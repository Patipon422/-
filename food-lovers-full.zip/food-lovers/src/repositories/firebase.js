import {readFirebaseConfig} from '../utils/firebase-config.js';
import {bangkokDay} from '../utils/visitors.js';
import {uuid} from '../utils/core.js';
import {initializeApp} from 'firebase/app';
import {getAuth,GoogleAuthProvider,signInWithPopup,signOut} from 'firebase/auth';
import {getFirestore,collection,query,where,limit,getDocs,doc,setDoc,deleteDoc,serverTimestamp,onSnapshot,orderBy,documentId,startAfter} from 'firebase/firestore';
import {getStorage,ref,uploadBytesResumable,getDownloadURL,getBlob} from 'firebase/storage';
import {getFunctions,httpsCallable} from 'firebase/functions';
import {initializeAppCheck,ReCaptchaV3Provider,ReCaptchaEnterpriseProvider} from 'firebase/app-check';
export class FirebaseRepository{
 constructor(){this.mode='firebase';this.blobs=[];}
 async init(){
  const {appCheckSiteKey,appCheckProvider,...config}=readFirebaseConfig(window.FOOD_LOVERS_FIREBASE,import.meta.env);
  this.app=initializeApp(config);
  const Provider=appCheckProvider==='v3'?ReCaptchaV3Provider:ReCaptchaEnterpriseProvider;
  initializeAppCheck(this.app,{provider:new Provider(appCheckSiteKey),isTokenAutoRefreshEnabled:true});
  this.auth=getAuth(this.app);this.auth.languageCode='th';
  this.db=getFirestore(this.app);this.storage=getStorage(this.app);
  this.functions=getFunctions(this.app,'asia-southeast1');
  await this.auth.authStateReady();
 }
 watchVisitorStats(callback,onError){
  let total,daily,totalReady=false,dayReady=false,day='',stopDay,stopped=false,failed=false;
  const value=(snap,key)=>snap.exists()?snap.data()[key]:(snap.metadata.fromCache?null:0);
  const publish=()=>{if(!stopped&&!failed&&totalReady&&dayReady)callback({
   totalVisits:value(total,'visits'),totalBrowsers:value(total,'uniqueBrowsers'),
   todayVisits:value(daily,'visits'),day,
   fromCache:total.metadata.fromCache||daily.metadata.fromCache,
  });};
  const fail=err=>{failed=true;if(!stopped)onError(err);};
  const stopTotal=onSnapshot(doc(this.db,'publicStats','total'),{includeMetadataChanges:true},snap=>{total=snap;totalReady=true;publish();},fail);
  const updateDay=()=>{
   const next=bangkokDay();if(next===day)return;
   day=next;dayReady=false;stopDay?.();
   stopDay=onSnapshot(doc(this.db,'dailyStats',day),{includeMetadataChanges:true},snap=>{daily=snap;dayReady=true;publish();},fail);
  };
  updateDay();const timer=setInterval(updateDay,60000);
  return ()=>{stopped=true;stopTotal();stopDay?.();clearInterval(timer);};
 }
 watchNotifications(uid,callback){return onSnapshot(query(collection(this.db,`users/${uid}/notifications`),limit(50)),snap=>callback(snap.docs.map(d=>({id:d.id,...d.data(),createdAt:d.data().createdAt?.toMillis?.()||Date.now()}))),err=>console.error('Notification subscription',err));}
 async login(){await signInWithPopup(this.auth,new GoogleAuthProvider());await this.call('ensureProfile',{});}
 async logout(){await signOut(this.auth);}
 async call(name,data){return (await httpsCallable(this.functions,name)(data)).data;}
 async rows(path,...constraints){
  const rows=[];let cursor;
  do {
   const page=await getDocs(query(collection(this.db,path),...constraints,orderBy(documentId()),...(cursor?[startAfter(cursor)]:[]),limit(200)));
   rows.push(...page.docs.map(d=>{const x={id:d.id,...d.data()};for(const k of ['createdAt','updatedAt'])if(x[k]?.toMillis)x[k]=x[k].toMillis();if(x.location)x.location={latitude:x.location.latitude,longitude:x.location.longitude};return x;}));
   cursor=page.size===200?page.docs.at(-1):null;
  } while(cursor);
  return rows;
 }
 async url(path){try{if(!path||path==='/service.svg')return '/service.svg';if(path.startsWith('public/'))return getDownloadURL(ref(this.storage,path));if(path.startsWith('pending/')){const blob=await getBlob(ref(this.storage,path));const url=URL.createObjectURL(blob);this.blobs.push(url);return url;}return '/service.svg';}catch{return '/service.svg';}}
 async load(){this.blobs.forEach(URL.revokeObjectURL);this.blobs=[];const u=this.auth.currentUser;const admin=u?Boolean((await u.getIdTokenResult()).claims.admin):false;const state={user:u?{uid:u.uid,displayName:u.displayName,admin}:null,shops:[],reviews:[],bookmarks:[],notifications:[],reports:[],auditLogs:[],users:[]};state.shops=await this.rows('shops',...(admin?[]:[where('status','==','approved')]));state.reviews=await this.rows('reviews',...(admin?[]:[where('status','==','published')]));if(u){if(!admin){const own=await this.rows('shops',where('submittedBy','==',u.uid));state.shops=[...new Map([...state.shops,...own].map(s=>[s.id,s])).values()];const ownReviews=await this.rows('reviews',where('userId','==',u.uid));state.reviews=[...new Map([...state.reviews,...ownReviews].map(r=>[r.id,r])).values()];}state.bookmarks=(await this.rows(`users/${u.uid}/bookmarks`)).map(b=>b.shopId);state.notifications=await this.rows(`users/${u.uid}/notifications`);if(admin){state.users=await this.rows('users');state.reports=await this.rows('reports');state.auditLogs=await this.rows('auditLogs');}}
 await Promise.all(state.shops.map(async s=>{s.storagePaths=s.images||[];s.images=await Promise.all(s.storagePaths.map(p=>this.url(p)));s.coverImage=s.images[0]||'/service.svg';}));await Promise.all(state.reviews.map(async r=>{r.storagePaths=r.images||[];r.images=await Promise.all(r.storagePaths.map(p=>this.url(p)));}));this.state=state;return state;}
 async bookmark(id){const uid=this.auth.currentUser?.uid;if(!uid)throw Error('กรุณาเข้าสู่ระบบ');const r=doc(this.db,'users',uid,'bookmarks',id);if(this.state.bookmarks.includes(id))await deleteDoc(r);else await setDoc(r,{shopId:id,createdAt:serverTimestamp()});}
 async upload(files){if(!this.auth.currentUser)throw Error('กรุณาเข้าสู่ระบบ');return Promise.all([...files].map(async file=>{if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>5*1024*1024)throw Error('ไฟล์ต้องเป็น JPEG, PNG, WebP ไม่เกิน 5 MB');const path=`pending/${this.auth.currentUser.uid}/${uuid()}`;await new Promise((resolve,reject)=>{uploadBytesResumable(ref(this.storage,path),file,{contentType:file.type}).on('state_changed',s=>{document.querySelector('#toast').textContent=`กำลังอัปโหลด ${Math.round(s.bytesTransferred/s.totalBytes*100)}%`;},reject,resolve);});return path;}));}
 async submitShop(s,id){const old=this.state.shops.find(x=>x.id===id);const images=s.images.filter(p=>p.startsWith('pending/')||p.startsWith('public/'));await this.call('submitShop',{shop:{...s,images:images.length?images:old?.storagePaths||[],coverImage:''},id:id||null});}
 async review(shopId,r,remove=false){const old=this.state.reviews.find(x=>x.shopId===shopId&&x.userId===this.auth.currentUser.uid);await this.call('saveReview',{shopId,remove,review:{...r,images:r.images?.some(p=>p.startsWith('pending/'))?r.images:old?.storagePaths||[]}});}
 async moderate(id,status,reason){await this.call('moderateShop',{id,status,reason});}
 async hideReview(id){await this.call('moderateReview',{id});}
 async report(data){await this.call('reportContent',data);}
 async resolveReport(id){await this.call('resolveReport',{id});}
}
