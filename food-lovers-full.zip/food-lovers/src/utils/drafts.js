// Store form text only; file inputs must be reselected after a reload.
export function draftKey(mode, uid, shopId = '') {
 return `kin-dee-draft-v1:${mode}:${encodeURIComponent(uid)}:${encodeURIComponent(shopId || 'new')}`;
}
export function saveDraft(storage, key, fields) {
 storage.setItem(key, JSON.stringify({version:1, fields}));
}
export function readDraft(storage, key) {
 const raw=storage.getItem(key);
 if(!raw)return null;
 const draft=JSON.parse(raw);
 if(draft.version!==1 || !Array.isArray(draft.fields))throw Error('อ่านแบบร่างเดิมไม่ได้');
 return draft.fields.filter(pair=>Array.isArray(pair)&&pair.length===2&&pair.every(v=>typeof v==='string'));
}
export function clearDraft(storage, key) {storage.removeItem(key);}
