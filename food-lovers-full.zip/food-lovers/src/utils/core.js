export function escapeHTML(v=''){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
export function safeURL(v){try{const u=new URL(v);return ['http:','https:'].includes(u.protocol)?u.href:'';}catch{return '';}}
export function openingStatus(shop,now=new Date()){
 const parts=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Bangkok',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now).map(p=>[p.type,p.value]));
 const date=`${parts.year}-${parts.month}-${parts.day}`, day=new Date(`${date}T00:00:00Z`).getUTCDay(),minute=+parts.hour*60+(+parts.minute);
 if(shop.specialClosures?.includes(date))return false;
 if(!shop.openingHours || !Object.hasOwn(shop.openingHours,day))return null;
 const mins=s=>{if(!/^\d{2}:\d{2}$/.test(s))return NaN;const [h,m]=s.split(':').map(Number);return h<24&&m<60?h*60+m:NaN;};
 const active=(shop.openingHours[day]||[]).some(p=>{const a=mins(p.open),b=mins(p.close);return a<b?minute>=a&&minute<b:a>b&&minute>=a;});
 const yesterday=new Date(`${date}T00:00:00Z`);yesterday.setUTCDate(yesterday.getUTCDate()-1);
 return active || (!shop.specialClosures?.includes(yesterday.toISOString().slice(0,10))&&(shop.openingHours[(day+6)%7]||[]).some(p=>mins(p.open)>mins(p.close)&&minute<mins(p.close)));
}
export function distance(a,b){const r=Math.PI/180,dl=(b.latitude-a.latitude)*r,dn=(b.longitude-a.longitude)*r;const h=Math.sin(dl/2)**2+Math.cos(a.latitude*r)*Math.cos(b.latitude*r)*Math.sin(dn/2)**2;return 6371*2*Math.atan2(Math.sqrt(h),Math.sqrt(1-h));}
export function filterShops(shops,f={},position){let result=shops.filter(s=>s.status==='approved'&&(!f.q||[s.name,s.description,...s.tags||[],...s.menus||[]].join(' ').toLowerCase().includes(f.q.toLowerCase()))&&(!f.category||s.category===f.category)&&(!f.price||String(s.priceLevel)===f.price)&&(!f.open||openingStatus(s)===true)&&(!f.tag||s.tags?.includes(f.tag)));
 return result.sort((a,b)=>f.sort==='rating'?(b.ratingAverage-a.ratingAverage):f.sort==='reviews'?b.reviewCount-a.reviewCount:f.sort==='distance'&&position?distance(position,a.location)-distance(position,b.location):(b.createdAt||0)-(a.createdAt||0));}
export function average(reviews){const r=reviews.filter(r=>r.status==='published');return {reviewCount:r.length,ratingAverage:r.length?r.reduce((a,r)=>a+r.rating,0)/r.length:0};}
export function validateReview(r){if(!Number.isInteger(r.rating)||r.rating<1||r.rating>5||typeof r.text!=='string'||r.text.trim().length<3||r.text.length>2000)throw Error('กรุณาให้คะแนน 1–5 ดาว และเขียนรีวิว 3–2,000 ตัวอักษร');}
export function uuid(){if(globalThis.crypto?.randomUUID)return globalThis.crypto.randomUUID();const a=new Uint8Array(16);globalThis.crypto.getRandomValues(a);a[6]=(a[6]&15)|64;a[8]=(a[8]&63)|128;const h=[...a].map(v=>v.toString(16).padStart(2,'0')).join('');return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;}
