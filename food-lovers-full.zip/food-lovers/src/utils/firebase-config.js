const fields = {
  apiKey: 'VITE_FIREBASE_API_KEY',
  authDomain: 'VITE_FIREBASE_AUTH_DOMAIN',
  projectId: 'VITE_FIREBASE_PROJECT_ID',
  storageBucket: 'VITE_FIREBASE_STORAGE_BUCKET',
  appId: 'VITE_FIREBASE_APP_ID',
  appCheckSiteKey: 'VITE_APP_CHECK_SITE_KEY',
};

export function readFirebaseConfig(runtime = {}, env = {}) {
  const config = Object.fromEntries(Object.entries(fields).map(([key, variable]) =>
    [key, String(runtime?.[key] || env[variable] || '').trim()]));
  config.appCheckProvider = runtime?.appCheckProvider || env.VITE_APP_CHECK_PROVIDER || 'enterprise';
  const missing = Object.keys(fields).filter(key => !config[key] || /^(YOUR_|REPLACE_|<)/i.test(config[key]));
  if (missing.length) {
    const error = new Error(`กรุณากรอก ${missing.join(', ')} ใน firebase-config.js แล้วเผยแพร่ใหม่`);
    error.code = 'app/config-missing';
    throw error;
  }
  if (!['enterprise', 'v3'].includes(config.appCheckProvider)) throw Error('appCheckProvider ต้องเป็น enterprise หรือ v3');
  return config;
}
