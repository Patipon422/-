export const VISITOR_KEY = 'food-lovers-visitor-v1';
export const bangkokDay = (now = Date.now()) => new Date(now + 7 * 60 * 60 * 1000).toISOString().slice(0, 10);
const validId = value => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);

export function getVisitorId(storage, makeId) {
  try {
    const existing = storage.getItem(VISITOR_KEY);
    if (validId(existing)) return existing;
    const id = makeId();
    if (!validId(id)) return null;
    storage.setItem(VISITOR_KEY, id);
    return id;
  } catch {
    // Do not manufacture a new visitor on every refresh if storage is blocked.
    return null;
  }
}

export const displayCount = value => Number.isSafeInteger(value) && value >= 0 ? value.toLocaleString('th-TH') : '—';
