import {initializeApp,applicationDefault} from '../functions/node_modules/firebase-admin/lib/app/index.js';
import {getAuth} from '../functions/node_modules/firebase-admin/lib/auth/index.js';
const uid=process.argv[2];if(!uid)throw Error('Usage: GOOGLE_APPLICATION_CREDENTIALS=/secure/path.json node scripts/set-admin.mjs USER_UID');
initializeApp({credential:applicationDefault()});const auth=getAuth(),user=await auth.getUser(uid);await auth.setCustomUserClaims(uid,{...user.customClaims,admin:true});console.log('Admin claim updated. Sign out and sign in again.');
