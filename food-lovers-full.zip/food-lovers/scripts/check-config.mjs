import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {loadEnv} from 'vite';
import {readFirebaseConfig} from '../src/utils/firebase-config.js';
try {
  const context = {window: {}};
  vm.runInNewContext(await readFile('public/firebase-config.js', 'utf8'), context, {timeout: 1000});
  readFirebaseConfig(context.window.FOOD_LOVERS_FIREBASE, {...loadEnv('production', process.cwd(), ''), ...process.env});
  console.log('Firebase configuration is complete. This checks fields only, not connectivity.');
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
