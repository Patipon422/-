// Copy the public web app configuration from Firebase Console > Project settings.
// This file is public. NEVER put a service-account private key or secret here.
// Source workflow: edit public/firebase-config.js and run npm run build.
// Prebuilt workflow: edit dist/firebase-config.js before uploading dist/.
window.FOOD_LOVERS_FIREBASE = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  appId: '',
  appCheckSiteKey: '',
  appCheckProvider: 'enterprise', // Use 'v3' for an existing reCAPTCHA v3 registration.
};
